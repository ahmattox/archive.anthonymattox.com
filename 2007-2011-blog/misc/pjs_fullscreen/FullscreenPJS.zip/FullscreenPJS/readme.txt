This is a quick proof of concept in creating a full browser Processing.js script.

For more info: http://anthonymattox.com/full-browser-processing-js
Processing.js: http://processingjs.org/


The included PDE file will not run in the processing IDE because it includes functions declared outside of itself. It will also not work with 3d renderers.

Included audio was cannibalized from some other project of mine.

have fun!


Created by Anthony Mattox
July 2011